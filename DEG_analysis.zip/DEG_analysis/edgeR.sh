#!/bin/bash

# Function to normalize the count matrix and replace zeroes with median values
normalize_count_matrix() {
  local input_file=$1
  local output_file=$2
  
  # Check if the input file exists
  if [[ ! -f "$input_file" ]]; then
    echo "Error: Input file $input_file not found!"
    exit 1
  fi
  
  # Create an output directory if it doesn't exist
  output_dir=$(dirname "$output_file")
  if [[ ! -d "$output_dir" ]]; then
    mkdir -p "$output_dir"
  fi
  
  # Extract gene names (first column) and sample IDs (second row)
  gene_names=$(head -n 1 "$input_file" | cut -f 1)
  sample_ids=$(head -n 2 "$input_file" | tail -n 1)
  
  # Save the count matrix excluding first row and first column (metadata)
  tail -n +2 "$input_file" | cut -f 2- > count_matrix_without_metadata.txt
  
  # Normalize the count matrix using R and edgeR
  Rscript -e "
    # Check if edgeR is installed
    if (!requireNamespace('edgeR', quietly = TRUE)) {
      stop('edgeR package is not installed. Please install it using install.packages(\\\"edgeR\\\").')
    }
    
    library(edgeR)
    
    # Load count matrix
    count_matrix <- read.table('count_matrix_without_metadata.txt', header = FALSE)
    
    # Replace zeros with column-wise median
    count_matrix[count_matrix == 0] <- apply(count_matrix, 2, function(x) median(x[x > 0], na.rm = TRUE))
    
    # Create DGEList object and normalize using TMM
    dge <- DGEList(counts = count_matrix)
    dge <- calcNormFactors(dge, method = 'TMM')
    
    # Get normalized counts
    normalized_counts <- cpm(dge, normalized.lib.sizes = TRUE)
    
    # Save normalized counts to file
    write.table(normalized_counts, 'normalized_counts.txt', sep = '\t', quote = FALSE, col.names = FALSE, row.names = TRUE)
  "
  
  # Check if the normalized counts file was created
  if [[ ! -f "normalized_counts.txt" ]]; then
    echo "Error: Normalized counts file not generated!"
    exit 1
  fi

  # Re-add gene names and sample IDs to the normalized matrix output
  paste <(echo -e "$gene_names") <(tail -n +2 normalized_counts.txt) > "$output_file"
  
  # Cleanup temporary files
  rm count_matrix_without_metadata.txt normalized_counts.txt
}

# Example usage
input_file="$1"  # Input file (first argument)
output_file="$2"  # Output file (second argument)

normalize_count_matrix "$input_file" "$output_file"

echo "Normalization and zero-replacement complete. Output saved to $output_file."
