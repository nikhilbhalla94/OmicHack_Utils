#!/bin/bash

# Usage function to display help for the script
usage() {
  echo "Usage: $0 -i <counts_matrix.csv> -m <metadata.csv> [-o <output_directory>]"
  exit 1
}

# Default output directory
output_dir="./deg_results"

# Parse command-line arguments
while getopts ":i:m:o:" opt; do
  case $opt in
    i) counts_file="$OPTARG" ;;
    m) metadata_file="$OPTARG" ;;
    o) output_dir="$OPTARG" ;;
    *) usage ;;
  esac
done

# Check if mandatory arguments are provided
if [ -z "$counts_file" ] || [ -z "$metadata_file" ]; then
  echo "Error: Input files are required."
  usage
fi

# Check if output directory exists, if not, create it
if [ ! -d "$output_dir" ]; then
  mkdir -p "$output_dir"
fi

# Generate R script for DEG analysis using DESeq2
r_script="deg_analysis.R"
cat <<EOF > $r_script
library(DESeq2)
library(readr)

# Read input data
counts <- read.csv("$counts_file", row.names=1)
sample_info <- read.csv("$metadata_file", header=TRUE)

# Ensure sample names match between counts and metadata
if (!all(colnames(counts) %in% sample_info\$sample)) {
  stop("Error: Sample names in counts matrix do not match those in metadata file.")
}

# Reorder sample_info to match counts columns
sample_info <- sample_info[match(colnames(counts), sample_info\$sample), ]

# Create DESeq2 dataset
dds <- DESeqDataSetFromMatrix(countData = counts, colData = sample_info, design = ~ condition)

# Pre-filtering: remove rows with only zero or one read
dds <- dds[rowSums(counts(dds)) > 1, ]

# Run DESeq2
dds <- DESeq(dds)

# Save normalized counts
normalized_counts <- counts(dds, normalized=TRUE)
write.csv(normalized_counts, file="$output_dir/normalized_counts.csv")

# Differential expression analysis
groups <- unique(sample_info\$condition)
for (i in 1:(length(groups)-1)) {
  for (j in (i+1):length(groups)) {
    # Forward direction
    contrast <- c("condition", groups[i], groups[j])
    res <- results(dds, contrast=contrast)
    res <- res[order(res\$padj), ]
    result_file <- paste0("$output_dir/DEG_", groups[j], "_vs_", groups[i], ".csv")
    write.csv(as.data.frame(res), file=result_file)
    
    # Reverse direction
    contrast <- c("condition", groups[j], groups[i])
    res <- results(dds, contrast=contrast)
    res <- res[order(res\$padj), ]
    result_file <- paste0("$output_dir/DEG_", groups[i], "_vs_", groups[j], ".csv")
    write.csv(as.data.frame(res), file=result_file)
  }
}
EOF

# Run the R script
Rscript $r_script

# Cleanup: Remove the generated R script
rm $r_script

echo "DEG analysis and data normalization completed. Results are saved in the directory: $output_dir."
