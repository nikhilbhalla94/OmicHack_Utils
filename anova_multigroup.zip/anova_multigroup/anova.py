import pandas as pd
from scipy.stats import f_oneway
import argparse

# Set up argument parsing
parser = argparse.ArgumentParser(description='Run ANOVA on gene count matrix.')
parser.add_argument('-i', '--input', type=str, required=True, help='Path to the input CSV file')
args = parser.parse_args()

# Load the data
file_path = args.input
data = pd.read_csv(file_path, sep=',', header=0, index_col=0)

# Extract the group labels by removing replicate numbers from column headers
group_labels = data.columns.str.extract(r'([A-Za-z]+)')[0]
unique_groups = group_labels.unique()

# Prepare a dictionary to store ANOVA results
anova_results = {'F_statistic': [], 'p_value': []}

# Run ANOVA for each gene and store results
for gene in data.index:
    group_data = []
    for group in unique_groups:
        # Collect data for each group by selecting the relevant columns
        group_values = data.loc[gene, data.columns[group_labels == group]]
        group_data.append(group_values.dropna().values)
    
    # Check if all groups have at least two samples
    if all(len(values) > 1 for values in group_data):
        # Perform ANOVA
        anova_result = f_oneway(*group_data)
        anova_results['F_statistic'].append(anova_result.statistic)
        anova_results['p_value'].append(anova_result.pvalue)
    else:
        # Append NaN if insufficient samples for ANOVA
        anova_results['F_statistic'].append(float('nan'))
        anova_results['p_value'].append(float('nan'))

# Add the ANOVA results as new columns to the original DataFrame
data['F_statistic'] = anova_results['F_statistic']
data['p_value'] = anova_results['p_value']

# Save the final DataFrame
output_file_path = 'gene_matrix_with_anova_results.txt'
data.to_csv(output_file_path, sep='\t')

print(data)
print(f'ANOVA results saved to {output_file_path}')
